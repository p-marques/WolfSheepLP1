﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WolfSheepGameLP1
{
    public class WolfPiece : Piece
    {
        //overrides the letter to s
        public override char Unicode { get; } = 'W';
    }
}

