﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WolfSheepGameLP1
{
    public class SheepPiece : Piece
    {
        //overrides the letter to s
        public override char Unicode { get; } = 'S';
    }
}
